#include"SimpleDefn/SimpleDefn.h"
#include"PramDefn/PramDefn.h"
#include"CalcDefn/CalcDefn.h"
#include"ComplexDefn/ComplexDefn.h"

int main(){
    ComplexDefn A("ivan_calc", "'tetxttdsfo #234 #214ofesgono'");
    /*
    for(int i=0; i<120 ; i++){
        char a = i;
        std::cout<<i<<" "<<a<<'\n';
    }
    */
}