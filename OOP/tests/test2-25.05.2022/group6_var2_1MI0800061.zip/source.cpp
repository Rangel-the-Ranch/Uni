#include<iostream>

#include"traintravel.h"
#include"carTravel.h"
#include"combinedTrip.h"


int main(){

}