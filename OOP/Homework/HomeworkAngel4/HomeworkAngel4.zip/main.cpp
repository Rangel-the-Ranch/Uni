#include <iostream>
#include "MyString/MyString.h"


#include "Queues/PrioQueue.hpp"
int main()
{
	prioQueue<char> A;

	A.push(2,'3');
	A.push(1,'2');
	A.push(0,'1');
	A.pop();
	std::cout<<A.peek();
}