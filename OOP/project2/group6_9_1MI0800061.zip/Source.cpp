#include"Interface/Interface.h"

size_t XMLelement::uniqueIdNum = 1;
const myString Parser::BASE_ID = "_Base";

int main(){ 
    Interface i(true);
}
